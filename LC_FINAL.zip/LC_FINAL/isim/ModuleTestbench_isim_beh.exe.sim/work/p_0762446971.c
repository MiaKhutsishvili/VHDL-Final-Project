/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_1242562249;
static const char *ng2 = "Function validate ended without a return statement";

char *ieee_p_1242562249_sub_17126692536656888728_1035706684(char *, char *, int , int );
int ieee_p_1242562249_sub_1871261289446890672_1035706684(char *, char *, char *);


char *work_p_0762446971_sub_930075792419016715_2068902826(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t6[32];
    char t15[8];
    char t29[16];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    int t12;
    char *t13;
    char *t14;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    char *t20;
    int t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    char *t30;
    char *t31;
    int t32;
    unsigned int t33;
    int t34;
    int t35;
    char *t36;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 6;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (6 - 0);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t6 + 16U);
    t11 = (t8 + 0U);
    *((int *)t11) = 7;
    t11 = (t8 + 4U);
    *((int *)t11) = 0;
    t11 = (t8 + 8U);
    *((int *)t11) = -1;
    t12 = (0 - 7);
    t10 = (t12 * -1);
    t10 = (t10 + 1);
    t11 = (t8 + 12U);
    *((unsigned int *)t11) = t10;
    t11 = (t4 + 4U);
    t13 = ((STD_STANDARD) + 384);
    t14 = (t11 + 88U);
    *((char **)t14) = t13;
    t16 = (t11 + 56U);
    *((char **)t16) = t15;
    *((int *)t15) = 0;
    t17 = (t11 + 80U);
    *((unsigned int *)t17) = 4U;
    t18 = (t5 + 4U);
    t19 = (t3 != 0);
    if (t19 == 1)
        goto LAB3;

LAB2:    t20 = (t5 + 12U);
    *((char **)t20) = t6;
    t21 = 0;
    t22 = 4;

LAB4:    if (t21 <= t22)
        goto LAB5;

LAB7:    t7 = (t11 + 56U);
    t8 = *((char **)t7);
    t9 = *((int *)t8);
    t7 = ieee_p_1242562249_sub_17126692536656888728_1035706684(IEEE_P_1242562249, t29, t9, 16);
    t13 = (t29 + 12U);
    t10 = *((unsigned int *)t13);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t7, t10);
    t14 = (t29 + 0U);
    t12 = *((int *)t14);
    t16 = (t29 + 4U);
    t21 = *((int *)t16);
    t17 = (t29 + 8U);
    t22 = *((int *)t17);
    t23 = (t2 + 0U);
    t24 = (t23 + 0U);
    *((int *)t24) = t12;
    t24 = (t23 + 4U);
    *((int *)t24) = t21;
    t24 = (t23 + 8U);
    *((int *)t24) = t22;
    t25 = (t21 - t12);
    t27 = (t25 * t22);
    t27 = (t27 + 1);
    t24 = (t23 + 12U);
    *((unsigned int *)t24) = t27;

LAB1:    return t0;
LAB3:    *((char **)t18) = t3;
    goto LAB2;

LAB5:    t23 = (t11 + 56U);
    t24 = *((char **)t23);
    t25 = *((int *)t24);
    t26 = (t21 - 0);
    t10 = (t26 * 1);
    xsi_vhdl_check_range_of_index(0, 6, 1, t21);
    t27 = (8U * t10);
    t28 = (0 + t27);
    t23 = (t3 + t28);
    t30 = (t29 + 0U);
    t31 = (t30 + 0U);
    *((int *)t31) = 7;
    t31 = (t30 + 4U);
    *((int *)t31) = 0;
    t31 = (t30 + 8U);
    *((int *)t31) = -1;
    t32 = (0 - 7);
    t33 = (t32 * -1);
    t33 = (t33 + 1);
    t31 = (t30 + 12U);
    *((unsigned int *)t31) = t33;
    t34 = ieee_p_1242562249_sub_1871261289446890672_1035706684(IEEE_P_1242562249, t23, t29);
    t35 = (t25 + t34);
    t31 = (t11 + 56U);
    t36 = *((char **)t31);
    t31 = (t36 + 0);
    *((int *)t31) = t35;

LAB6:    if (t21 == t22)
        goto LAB7;

LAB8:    t9 = (t21 + 1);
    t21 = t9;
    goto LAB4;

LAB9:;
}

char *work_p_0762446971_sub_16729817252272099908_2068902826(char *t1, char *t2)
{
    char t3[128];
    char t4[24];
    char t5[32];
    char t12[16];
    char t17[8];
    char t26[16];
    char *t0;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    char *t10;
    int t11;
    char *t13;
    int t14;
    char *t15;
    char *t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;

LAB0:    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 6;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (6 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = (t5 + 16U);
    t10 = (t7 + 0U);
    *((int *)t10) = 7;
    t10 = (t7 + 4U);
    *((int *)t10) = 0;
    t10 = (t7 + 8U);
    *((int *)t10) = -1;
    t11 = (0 - 7);
    t9 = (t11 * -1);
    t9 = (t9 + 1);
    t10 = (t7 + 12U);
    *((unsigned int *)t10) = t9;
    t10 = (t12 + 0U);
    t13 = (t10 + 0U);
    *((int *)t13) = 7;
    t13 = (t10 + 4U);
    *((int *)t13) = 0;
    t13 = (t10 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - 7);
    t9 = (t14 * -1);
    t9 = (t9 + 1);
    t13 = (t10 + 12U);
    *((unsigned int *)t13) = t9;
    t13 = (t3 + 4U);
    t15 = (t1 + 2552);
    t16 = (t13 + 88U);
    *((char **)t16) = t15;
    t18 = (t13 + 56U);
    *((char **)t18) = t17;
    xsi_type_set_default_value(t15, t17, 0);
    t19 = (t13 + 64U);
    t20 = (t15 + 72U);
    t21 = *((char **)t20);
    *((char **)t19) = t21;
    t22 = (t13 + 80U);
    *((unsigned int *)t22) = 8U;
    t23 = (t4 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t4 + 12U);
    *((char **)t25) = t5;
    t27 = work_p_0762446971_sub_930075792419016715_2068902826(t1, t26, t2);
    t28 = (t26 + 0U);
    t29 = *((int *)t28);
    t9 = (t29 - 15);
    t30 = (t9 * 1U);
    t31 = (0 + t30);
    t32 = (t27 + t31);
    t33 = (t13 + 56U);
    t34 = *((char **)t33);
    t33 = (t34 + 0);
    t35 = (8 - 15);
    t36 = (t35 * -1);
    t36 = (t36 + 1);
    t37 = (1U * t36);
    memcpy(t33, t32, t37);
    t6 = (t13 + 56U);
    t7 = *((char **)t6);
    xsi_vhdl_check_range_of_slice(7, 0, -1, 7, 0, -1);
    t0 = xsi_get_transient_memory(8U);
    memcpy(t0, t7, 8U);

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB4:;
}

char *work_p_0762446971_sub_16729817252272104276_2068902826(char *t1, char *t2)
{
    char t3[128];
    char t4[24];
    char t5[32];
    char t12[16];
    char t17[8];
    char t26[16];
    char *t0;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    char *t10;
    int t11;
    char *t13;
    int t14;
    char *t15;
    char *t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    char *t25;
    char *t27;
    char *t28;
    int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;
    int t35;
    unsigned int t36;
    unsigned int t37;

LAB0:    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 6;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (6 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = (t5 + 16U);
    t10 = (t7 + 0U);
    *((int *)t10) = 7;
    t10 = (t7 + 4U);
    *((int *)t10) = 0;
    t10 = (t7 + 8U);
    *((int *)t10) = -1;
    t11 = (0 - 7);
    t9 = (t11 * -1);
    t9 = (t9 + 1);
    t10 = (t7 + 12U);
    *((unsigned int *)t10) = t9;
    t10 = (t12 + 0U);
    t13 = (t10 + 0U);
    *((int *)t13) = 7;
    t13 = (t10 + 4U);
    *((int *)t13) = 0;
    t13 = (t10 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - 7);
    t9 = (t14 * -1);
    t9 = (t9 + 1);
    t13 = (t10 + 12U);
    *((unsigned int *)t13) = t9;
    t13 = (t3 + 4U);
    t15 = (t1 + 2552);
    t16 = (t13 + 88U);
    *((char **)t16) = t15;
    t18 = (t13 + 56U);
    *((char **)t18) = t17;
    xsi_type_set_default_value(t15, t17, 0);
    t19 = (t13 + 64U);
    t20 = (t15 + 72U);
    t21 = *((char **)t20);
    *((char **)t19) = t21;
    t22 = (t13 + 80U);
    *((unsigned int *)t22) = 8U;
    t23 = (t4 + 4U);
    t24 = (t2 != 0);
    if (t24 == 1)
        goto LAB3;

LAB2:    t25 = (t4 + 12U);
    *((char **)t25) = t5;
    t27 = work_p_0762446971_sub_930075792419016715_2068902826(t1, t26, t2);
    t28 = (t26 + 0U);
    t29 = *((int *)t28);
    t9 = (t29 - 7);
    t30 = (t9 * 1U);
    t31 = (0 + t30);
    t32 = (t27 + t31);
    t33 = (t13 + 56U);
    t34 = *((char **)t33);
    t33 = (t34 + 0);
    t35 = (0 - 7);
    t36 = (t35 * -1);
    t36 = (t36 + 1);
    t37 = (1U * t36);
    memcpy(t33, t32, t37);
    t6 = (t13 + 56U);
    t7 = *((char **)t6);
    xsi_vhdl_check_range_of_slice(7, 0, -1, 7, 0, -1);
    t0 = xsi_get_transient_memory(8U);
    memcpy(t0, t7, 8U);

LAB1:    return t0;
LAB3:    *((char **)t23) = t2;
    goto LAB2;

LAB4:;
}

unsigned char work_p_0762446971_sub_212458537973661704_2068902826(char *t1, char *t2)
{
    char t3[248];
    char t4[24];
    char t5[32];
    char t12[16];
    char t17[8];
    char t26[8];
    unsigned char t0;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    char *t10;
    int t11;
    char *t13;
    int t14;
    char *t15;
    char *t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned char t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned char t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned char t45;
    unsigned int t46;

LAB0:    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 6;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (6 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = (t5 + 16U);
    t10 = (t7 + 0U);
    *((int *)t10) = 7;
    t10 = (t7 + 4U);
    *((int *)t10) = 0;
    t10 = (t7 + 8U);
    *((int *)t10) = -1;
    t11 = (0 - 7);
    t9 = (t11 * -1);
    t9 = (t9 + 1);
    t10 = (t7 + 12U);
    *((unsigned int *)t10) = t9;
    t10 = (t12 + 0U);
    t13 = (t10 + 0U);
    *((int *)t13) = 7;
    t13 = (t10 + 4U);
    *((int *)t13) = 0;
    t13 = (t10 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - 7);
    t9 = (t14 * -1);
    t9 = (t9 + 1);
    t13 = (t10 + 12U);
    *((unsigned int *)t13) = t9;
    t13 = (t3 + 4U);
    t15 = (t1 + 2552);
    t16 = (t13 + 88U);
    *((char **)t16) = t15;
    t18 = (t13 + 56U);
    *((char **)t18) = t17;
    xsi_type_set_default_value(t15, t17, 0);
    t19 = (t13 + 64U);
    t20 = (t15 + 72U);
    t21 = *((char **)t20);
    *((char **)t19) = t21;
    t22 = (t13 + 80U);
    *((unsigned int *)t22) = 8U;
    t23 = (t3 + 124U);
    t24 = (t1 + 2552);
    t25 = (t23 + 88U);
    *((char **)t25) = t24;
    t27 = (t23 + 56U);
    *((char **)t27) = t26;
    xsi_type_set_default_value(t24, t26, 0);
    t28 = (t23 + 64U);
    t29 = (t24 + 72U);
    t30 = *((char **)t29);
    *((char **)t28) = t30;
    t31 = (t23 + 80U);
    *((unsigned int *)t31) = 8U;
    t32 = (t4 + 4U);
    t33 = (t2 != 0);
    if (t33 == 1)
        goto LAB3;

LAB2:    t34 = (t4 + 12U);
    *((char **)t34) = t5;
    t35 = work_p_0762446971_sub_16729817252272099908_2068902826(t1, t2);
    t36 = (t13 + 56U);
    t37 = *((char **)t36);
    t36 = (t37 + 0);
    memcpy(t36, t35, 8U);
    t6 = work_p_0762446971_sub_16729817252272104276_2068902826(t1, t2);
    t7 = (t23 + 56U);
    t10 = *((char **)t7);
    t7 = (t10 + 0);
    memcpy(t7, t6, 8U);
    t6 = (t13 + 56U);
    t7 = *((char **)t6);
    t8 = (5 - 0);
    t9 = (t8 * 1);
    t38 = (8U * t9);
    t39 = (0 + t38);
    t6 = (t2 + t39);
    t40 = 1;
    if (8U == 8U)
        goto LAB10;

LAB11:    t40 = 0;

LAB12:    if (t40 == 1)
        goto LAB7;

LAB8:    t33 = (unsigned char)0;

LAB9:    if (t33 != 0)
        goto LAB4;

LAB6:    t0 = (unsigned char)2;

LAB1:    return t0;
LAB3:    *((char **)t32) = t2;
    goto LAB2;

LAB4:    t0 = (unsigned char)3;
    goto LAB1;

LAB5:    xsi_error(ng2);
    t0 = 0;
    goto LAB1;

LAB7:    t16 = (t23 + 56U);
    t18 = *((char **)t16);
    t11 = (6 - 0);
    t42 = (t11 * 1);
    t43 = (8U * t42);
    t44 = (0 + t43);
    t16 = (t2 + t44);
    t45 = 1;
    if (8U == 8U)
        goto LAB16;

LAB17:    t45 = 0;

LAB18:    t33 = t45;
    goto LAB9;

LAB10:    t41 = 0;

LAB13:    if (t41 < 8U)
        goto LAB14;
    else
        goto LAB12;

LAB14:    t10 = (t7 + t41);
    t15 = (t6 + t41);
    if (*((unsigned char *)t10) != *((unsigned char *)t15))
        goto LAB11;

LAB15:    t41 = (t41 + 1);
    goto LAB13;

LAB16:    t46 = 0;

LAB19:    if (t46 < 8U)
        goto LAB20;
    else
        goto LAB18;

LAB20:    t19 = (t18 + t46);
    t20 = (t16 + t46);
    if (*((unsigned char *)t19) != *((unsigned char *)t20))
        goto LAB17;

LAB21:    t46 = (t46 + 1);
    goto LAB19;

LAB22:    goto LAB5;

LAB23:    goto LAB5;

}


void ieee_p_2592010699_sub_7991387870887201249_503743352();

void ieee_p_2592010699_sub_7991387870887201249_503743352();

extern void work_p_0762446971_init()
{
	static char *se[] = {(void *)work_p_0762446971_sub_930075792419016715_2068902826,(void *)work_p_0762446971_sub_16729817252272099908_2068902826,(void *)work_p_0762446971_sub_16729817252272104276_2068902826,(void *)work_p_0762446971_sub_212458537973661704_2068902826};
	xsi_register_didat("work_p_0762446971", "isim/ModuleTestbench_isim_beh.exe.sim/work/p_0762446971.didat");
	xsi_register_subprogram_executes(se);
	xsi_register_resolution_function(1, 2, (void *)ieee_p_2592010699_sub_7991387870887201249_503743352, 3);
	xsi_register_resolution_function(2, 2, (void *)ieee_p_2592010699_sub_7991387870887201249_503743352, 3);
}
