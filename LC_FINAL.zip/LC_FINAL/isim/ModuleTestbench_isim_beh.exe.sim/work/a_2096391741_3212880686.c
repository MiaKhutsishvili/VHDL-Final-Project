/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/LC_FINAL/ControlUnit.vhd";
extern char *IEEE_P_2592010699;
extern char *WORK_P_0762446971;

unsigned char ieee_p_2592010699_sub_2763492388968962707_503743352(char *, char *, unsigned int , unsigned int );
unsigned char work_p_0762446971_sub_212458537973661704_2068902826(char *, char *);


static void work_a_2096391741_3212880686_p_0(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    int t9;
    unsigned int t10;
    unsigned char t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    int t19;
    int t21;
    char *t22;
    int t24;
    char *t25;
    int t27;
    char *t28;
    int t30;
    char *t31;
    int t33;
    char *t34;
    int t36;
    char *t37;
    int t39;
    char *t40;
    int t42;
    char *t43;
    int t45;
    char *t46;
    int t48;
    char *t49;
    int t51;
    char *t52;
    int t54;
    char *t55;
    int t57;
    char *t58;
    int t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    unsigned char t66;
    unsigned char t67;
    unsigned char t68;
    unsigned char t69;
    unsigned char t70;
    unsigned int t71;

LAB0:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 2112U);
    t2 = ieee_p_2592010699_sub_2763492388968962707_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4064);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(41, ng0);
    t3 = (t0 + 4144);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(43, ng0);
    t1 = (t0 + 2312U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t8 = (t2 == (unsigned char)3);
    if (t8 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1032U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t8 = (t2 == (unsigned char)3);
    if (t8 != 0)
        goto LAB8;

LAB9:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = 0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(45, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB6;

LAB8:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 2472U);
    t4 = *((char **)t1);
    t9 = *((int *)t4);
    if (t9 == 0)
        goto LAB11;

LAB19:    if (t9 == 1)
        goto LAB12;

LAB20:    if (t9 == 2)
        goto LAB13;

LAB21:    if (t9 == 3)
        goto LAB14;

LAB22:    if (t9 == 4)
        goto LAB15;

LAB23:    if (t9 == 5)
        goto LAB16;

LAB24:    if (t9 == 6)
        goto LAB17;

LAB25:
LAB18:
LAB10:    goto LAB6;

LAB11:    xsi_set_current_line(50, ng0);
    t1 = xsi_get_transient_memory(56U);
    memset(t1, 0, 56U);
    t5 = t1;
    t10 = (8U * 1U);
    t6 = t5;
    memset(t6, (unsigned char)2, t10);
    t11 = (t10 != 0);
    if (t11 == 1)
        goto LAB27;

LAB28:    t7 = (t0 + 4336);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t1, 56U);
    xsi_driver_first_trans_fast_port(t7);
    xsi_set_current_line(51, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 0U, 8U, 0LL);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 6552);
    t9 = xsi_mem_cmp(t1, t3, 8U);
    if (t9 == 1)
        goto LAB30;

LAB37:    t5 = (t0 + 6560);
    t17 = xsi_mem_cmp(t5, t3, 8U);
    if (t17 == 1)
        goto LAB30;

LAB38:    t7 = (t0 + 6568);
    t18 = xsi_mem_cmp(t7, t3, 8U);
    if (t18 == 1)
        goto LAB30;

LAB39:    t14 = (t0 + 6576);
    t19 = xsi_mem_cmp(t14, t3, 8U);
    if (t19 == 1)
        goto LAB30;

LAB40:    t16 = (t0 + 6584);
    t21 = xsi_mem_cmp(t16, t3, 8U);
    if (t21 == 1)
        goto LAB31;

LAB41:    t22 = (t0 + 6592);
    t24 = xsi_mem_cmp(t22, t3, 8U);
    if (t24 == 1)
        goto LAB32;

LAB42:    t25 = (t0 + 6600);
    t27 = xsi_mem_cmp(t25, t3, 8U);
    if (t27 == 1)
        goto LAB33;

LAB43:    t28 = (t0 + 6608);
    t30 = xsi_mem_cmp(t28, t3, 8U);
    if (t30 == 1)
        goto LAB33;

LAB44:    t31 = (t0 + 6616);
    t33 = xsi_mem_cmp(t31, t3, 8U);
    if (t33 == 1)
        goto LAB33;

LAB45:    t34 = (t0 + 6624);
    t36 = xsi_mem_cmp(t34, t3, 8U);
    if (t36 == 1)
        goto LAB33;

LAB46:    t37 = (t0 + 6632);
    t39 = xsi_mem_cmp(t37, t3, 8U);
    if (t39 == 1)
        goto LAB34;

LAB47:    t40 = (t0 + 6640);
    t42 = xsi_mem_cmp(t40, t3, 8U);
    if (t42 == 1)
        goto LAB34;

LAB48:    t43 = (t0 + 6648);
    t45 = xsi_mem_cmp(t43, t3, 8U);
    if (t45 == 1)
        goto LAB34;

LAB49:    t46 = (t0 + 6656);
    t48 = xsi_mem_cmp(t46, t3, 8U);
    if (t48 == 1)
        goto LAB34;

LAB50:    t49 = (t0 + 6664);
    t51 = xsi_mem_cmp(t49, t3, 8U);
    if (t51 == 1)
        goto LAB35;

LAB51:    t52 = (t0 + 6672);
    t54 = xsi_mem_cmp(t52, t3, 8U);
    if (t54 == 1)
        goto LAB35;

LAB52:    t55 = (t0 + 6680);
    t57 = xsi_mem_cmp(t55, t3, 8U);
    if (t57 == 1)
        goto LAB35;

LAB53:    t58 = (t0 + 6688);
    t60 = xsi_mem_cmp(t58, t3, 8U);
    if (t60 == 1)
        goto LAB35;

LAB54:
LAB36:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast_port(t1);

LAB29:    xsi_set_current_line(71, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t9 = *((int *)t3);
    t17 = (t9 + 1);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t17;
    xsi_driver_first_trans_fast(t1);
    goto LAB10;

LAB12:    xsi_set_current_line(74, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 8U, 8U, 0LL);
    xsi_set_current_line(75, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t8 = (t2 == (unsigned char)3);
    if (t8 != 0)
        goto LAB56;

LAB58:    xsi_set_current_line(78, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t9 = *((int *)t3);
    t17 = (t9 + 1);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t17;
    xsi_driver_first_trans_fast(t1);

LAB57:    goto LAB10;

LAB13:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 16U, 8U, 0LL);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t8 = (t2 == (unsigned char)2);
    if (t8 != 0)
        goto LAB59;

LAB61:    xsi_set_current_line(86, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t9 = *((int *)t3);
    t17 = (t9 + 1);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t17;
    xsi_driver_first_trans_fast(t1);

LAB60:    goto LAB10;

LAB14:    xsi_set_current_line(90, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 24U, 8U, 0LL);
    xsi_set_current_line(91, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t11 = *((unsigned char *)t3);
    t66 = (t11 == (unsigned char)1);
    if (t66 == 1)
        goto LAB68;

LAB69:    t1 = (t0 + 1672U);
    t4 = *((char **)t1);
    t67 = *((unsigned char *)t4);
    t68 = (t67 == (unsigned char)4);
    t8 = t68;

LAB70:    if (t8 == 1)
        goto LAB65;

LAB66:    t1 = (t0 + 1672U);
    t5 = *((char **)t1);
    t69 = *((unsigned char *)t5);
    t70 = (t69 == (unsigned char)6);
    t2 = t70;

LAB67:    if (t2 != 0)
        goto LAB62;

LAB64:    xsi_set_current_line(95, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t9 = *((int *)t3);
    t17 = (t9 + 1);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t17;
    xsi_driver_first_trans_fast(t1);

LAB63:    goto LAB10;

LAB15:    xsi_set_current_line(99, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 32U, 8U, 0LL);
    xsi_set_current_line(100, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t9 = *((int *)t3);
    t17 = (t9 + 1);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t17;
    xsi_driver_first_trans_fast(t1);
    goto LAB10;

LAB16:    xsi_set_current_line(103, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 40U, 8U, 0LL);
    xsi_set_current_line(104, ng0);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t9 = *((int *)t3);
    t17 = (t9 + 1);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = t17;
    xsi_driver_first_trans_fast(t1);
    goto LAB10;

LAB17:    xsi_set_current_line(107, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 4336);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    memcpy(t7, t3, 8U);
    xsi_driver_first_trans_delta(t1, 48U, 8U, 0LL);
    xsi_set_current_line(108, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t8 = *((unsigned char *)t3);
    t11 = (t8 == (unsigned char)2);
    if (t11 == 1)
        goto LAB74;

LAB75:    t1 = (t0 + 1672U);
    t4 = *((char **)t1);
    t66 = *((unsigned char *)t4);
    t67 = (t66 == (unsigned char)3);
    t2 = t67;

LAB76:    if (t2 != 0)
        goto LAB71;

LAB73:    xsi_set_current_line(111, ng0);
    t1 = (t0 + 4400);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);

LAB72:    xsi_set_current_line(113, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t1 = (t0 + 2768U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    memcpy(t1, t3, 56U);
    xsi_set_current_line(114, ng0);
    t1 = (t0 + 1192U);
    t3 = *((char **)t1);
    t1 = (t0 + 2768U);
    t4 = *((char **)t1);
    t9 = (6 - 0);
    t10 = (t9 * 1);
    t12 = (8U * t10);
    t71 = (0 + t12);
    t1 = (t4 + t71);
    memcpy(t1, t3, 8U);
    xsi_set_current_line(115, ng0);
    t1 = (t0 + 4208);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((int *)t6) = 0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(116, ng0);
    t1 = (t0 + 2768U);
    t3 = *((char **)t1);
    t2 = work_p_0762446971_sub_212458537973661704_2068902826(WORK_P_0762446971, t3);
    t1 = (t0 + 4464);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(117, ng0);
    t1 = (t0 + 4144);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB10;

LAB26:;
LAB27:    t12 = (56U / t10);
    xsi_mem_set_data(t5, t5, t10, t12);
    goto LAB28;

LAB30:    xsi_set_current_line(56, ng0);
    t61 = (t0 + 4272);
    t62 = (t61 + 56U);
    t63 = *((char **)t62);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    *((unsigned char *)t65) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t61);
    goto LAB29;

LAB31:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB29;

LAB32:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB29;

LAB33:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)4;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB29;

LAB34:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)5;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB29;

LAB35:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 4272);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)6;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB29;

LAB55:;
LAB56:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = 5;
    xsi_driver_first_trans_fast(t1);
    goto LAB57;

LAB59:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 4208);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((int *)t7) = 5;
    xsi_driver_first_trans_fast(t1);
    goto LAB60;

LAB62:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 4208);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t13 = (t7 + 56U);
    t14 = *((char **)t13);
    *((int *)t14) = 5;
    xsi_driver_first_trans_fast(t1);
    goto LAB63;

LAB65:    t2 = (unsigned char)1;
    goto LAB67;

LAB68:    t8 = (unsigned char)1;
    goto LAB70;

LAB71:    xsi_set_current_line(109, ng0);
    t1 = (t0 + 4400);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t13 = *((char **)t7);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB72;

LAB74:    t2 = (unsigned char)1;
    goto LAB76;

}


extern void work_a_2096391741_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2096391741_3212880686_p_0};
	xsi_register_didat("work_a_2096391741_3212880686", "isim/ModuleTestbench_isim_beh.exe.sim/work/a_2096391741_3212880686.didat");
	xsi_register_executes(pe);
}
